import * as React from "react";
import * as Radix from "@radix-ui/react-progress";

import { cn } from "@/lib/utils";

const Progress = React.forwardRef,
  React.ComponentPropsWithoutRef
>(({ className, value, ...props }, ref) => (
  
    
  
));
Progress.displayName = ProgressPrimitive.Root.displayName;

export { Progress };
