import * as React from "react";
import * as Radix from "@radix-ui/react-switch";

import { cn } from "@/lib/utils";

const Switch = React.forwardRef,
  React.ComponentPropsWithoutRef
>(({ className, ...props }, ref) => (
  
    
  
));
Switch.displayName = SwitchPrimitives.Root.displayName;

export { Switch };
