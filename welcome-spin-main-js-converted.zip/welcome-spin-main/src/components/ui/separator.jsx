import * from "react";
import * from "@radix-ui/react-separator";

import { cn } from "@/lib/utils";

const Separator = React.forwardRef,
  React.ComponentPropsWithoutRef
>(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => (
  
));
Separator.displayName = SeparatorPrimitive.Root.displayName;

export { Separator };
