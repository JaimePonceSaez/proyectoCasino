import * from "react";
import * from "@radix-ui/react-slider";

import { cn } from "@/lib/utils";

const Slider = React.forwardRef,
  React.ComponentPropsWithoutRef
>(({ className, ...props }, ref) => (
  
    
      
    
    
  
));
Slider.displayName = SliderPrimitive.Root.displayName;

export { Slider };
