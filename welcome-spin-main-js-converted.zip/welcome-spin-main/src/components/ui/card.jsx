import * from "react";

import { cn } from "@/lib/utils";

const Card = React.forwardRef>(({ className, ...props }, ref) => (
  
));
Card.displayName = "Card";

const CardHeader = React.forwardRef>(
  ({ className, ...props }, ref) => (
    
  ),
);
CardHeader.displayName = "CardHeader";

const CardTitle = React.forwardRef>(
  ({ className, ...props }, ref) => (
    
  ),
);
CardTitle.displayName = "CardTitle";

const CardDescription = React.forwardRef>(
  ({ className, ...props }, ref) => (
    
  ),
);
CardDescription.displayName = "CardDescription";

const CardContent = React.forwardRef>(
  ({ className, ...props }, ref) => ,
);
CardContent.displayName = "CardContent";

const CardFooter = React.forwardRef>(
  ({ className, ...props }, ref) => (
    
  ),
);
CardFooter.displayName = "CardFooter";

export { Card, CardHeader, CardFooter, CardTitle, CardDescription, CardContent };
