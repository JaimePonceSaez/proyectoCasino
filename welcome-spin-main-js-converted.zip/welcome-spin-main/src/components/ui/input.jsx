import * from "react";

import { cn } from "@/lib/utils";

const Input = React.forwardRef>(
  ({ className, type, ...props }, ref) => {
    return (
      
    );
  },
);
Input.displayName = "Input";

export { Input };
