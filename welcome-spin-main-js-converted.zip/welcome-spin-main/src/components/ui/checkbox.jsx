import * from "react";
import * from "@radix-ui/react-checkbox";
import { Check } from "lucide-react";

import { cn } from "@/lib/utils";

const Checkbox = React.forwardRef,
  React.ComponentPropsWithoutRef
>(({ className, ...props }, ref) => (
  
    
      
    
  
));
Checkbox.displayName = CheckboxPrimitive.Root.displayName;

export { Checkbox };
