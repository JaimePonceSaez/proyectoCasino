import * from "react";

import { cn } from "@/lib/utils";

export interface TextareaProps extends React.TextareaHTMLAttributes {}

const Textarea = React.forwardRef(({ className, ...props }, ref) => {
  return (
    
  );
});
Textarea.displayName = "Textarea";

export { Textarea };
